import React from 'react';
export function FormaSampleCard() {
  return <div className='rounded-xl border border-white/10 bg-[#0c0c0f] p-6 text-white'>forma/ Sample</div>;
}
